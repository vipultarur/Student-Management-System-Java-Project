import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.*;
import java.util.Scanner;

public class Connect {
    static Connection con;
    static String RED_BACKGROUND="\u001B[41m";
    static String ANSI_RESET="\u001b[0m";
    static String ANSI_RED="\u001b[31m";
	static String ANSI_GREEN = "\033[0;32m";
	static String ANSI_YELLOW="\033[0;33m";
	static String TEXT_BG_GREEN  = "\u001B[42m";
	static String CYAN_BACKGROUND="\u001B[46m";

    // -----------------------------------------DATABAS CONNECTION-------------------------------------------------------//
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public static Connection createc() {
        // load driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3309/students";
            String user = "root";
            String password = "vipul@2003#1";

            try {
                con = DriverManager.getConnection(url, user, password);
            } catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return con;

    }

    // -----------------------------------------SHOW ALL STUDENT RECORDS---------------------------------------//
    public static boolean ShowAllStudent() {
    	
        boolean f = false;
        int count = 0;
        try {
            Connection con = Connect.createc();
            String q = "select * from student;";
            Statement stmt = con.createStatement();

            ResultSet set = stmt.executeQuery(q);

            f = true;
            while (set.next()) {
                int Enroll = set.getInt(1);
                String sname = set.getString(2);
                String semail = set.getString(3);
                String sphone = set.getString(4);
                String sclg_name = set.getString(5);
                String scourse = set.getString(6);
                String scity = set.getString(7);
                String sgender=set.getString(8);
                
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t        "+TEXT_BG_GREEN+"  Enrollment Number    : | " + Enroll+"  "+ANSI_RESET);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Name         : | " + sname);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Email        : | " + semail);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student phone Number : | " + sphone);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student School Name : | " + sclg_name);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Class Name  : | " + scourse);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Gender       : | " + sgender);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student City Name    : |  " + scity);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                count ++;
                
            }
            if(count<=10)
            {
                System.out.println("\t\t       | |                "+RED_BACKGROUND+" Total Student :"+0+count+" "+ANSI_RESET+"                                               | |");

            }
            else
            {
                System.out.println("\t\t       | |                "+RED_BACKGROUND+"Total Student :"+count+" "+ANSI_RESET+"                                               | |");
	
            }
            
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");


        } catch (Exception e) {
            e.printStackTrace();
            ShowAllStudent();
        }
        return f;
    }

    // ---------------------------------------INSEER DATA TO  DATABASE---------------------------------------------------//

    public static boolean insertRecord(Students st) {

        boolean f = false;
        int s1;
        // oneStudentrecord();

        try {

                Connection con= Connect.createc();

            String q = "insert into student(Enroll,sname,semail,sphone,sclg_name,scopurse,scity,sgender) values(?,?,?,?,?,?,?,?)";
            PreparedStatement psmt = con.prepareStatement(q);
            psmt.setInt(1, st.getEnroll());
            psmt.setString(2, st.getSname());
            psmt.setString(3, st.getSemail());
            psmt.setLong(4, st.getSphone());
            psmt.setString(5, st.getSclg_name());
            psmt.setString(6, st.getScourse());
            psmt.setString(7, st.getScity());
            psmt.setString(8,st.getSgender());

            psmt.executeUpdate();
            f = true;

            
        } catch (Exception e) {
        	System.out.println("\t\t       | |               "+ANSI_RED+"         Student is not inserted.....          "+ANSI_RESET+"                    | |");
            System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    }
        return f;
    }

    // -----------------------------------------DELETE STUDENT RECORD-----------------------------------------------------//
    public static boolean deleteStudent(int userid) {
        boolean f = false;
        try {
            Connection con = Connect.createc();
            String q = "delete from student where Enroll=?";
            PreparedStatement psmt = con.prepareStatement(q);
            psmt.setInt(1, userid);

            psmt.executeUpdate();
            f = true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }
  //--------------------------------------------------
    public static boolean deleteAllStudent() {
    	boolean f = false;
        try {
            Connection con = Connect.createc();
            String q = "truncate table student";
            PreparedStatement psmt = con.prepareStatement(q);

            psmt.executeUpdate();
            f = true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
	}
    
    // -------------------------------------------SHOW ONE STUDENT RECORD---------------------------------------------//

    public static boolean oneStudentrecord() {

        // int s1;
        String s1;

        Scanner sc = new Scanner(System.in);
        s1 = sc.nextLine();
        boolean f = false;
        try {
            Connection con = Connect.createc();
            String q = "select * from student where Enroll=" + s1;
            
            Statement stmt = con.createStatement();

            ResultSet set = stmt.executeQuery(q);

            f = true;
            while (set.next()) {
                int Enroll = set.getInt(1);
                String sname = set.getString(2);
                String semail = set.getString(3);
                String sphone = set.getString(4);
                String sclg_name = set.getString(5);
                String scourse = set.getString(6);
                String scity = set.getString(7);
                String sgender=set.getString(8);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t\t\t        "+TEXT_BG_GREEN+"  Enrollment Number    : | " + Enroll+"  "+ANSI_RESET);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Name         : | " + sname);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Email        : | " + semail);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student phone Number : | " + sphone);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student School Name : | " + sclg_name);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Class Name  : | " + scourse);
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Gender       : | " + sgender);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student City Name    : |  " + scity);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    // ---------------------------------------------UPDATE STUDENT  RECORD-------------------------------------------------------//

    public static boolean UpdateStudent() {

        int s1;

        Scanner sc = new Scanner(System.in);
        s1 = sc.nextInt();
        boolean f = false;
        try {

            Connection con = Connect.createc();
            String q = "select * from student where Enroll=" + s1;
           
            Statement stmt = con.createStatement();

            ResultSet set = stmt.executeQuery(q);

            f = true;
            while (set.next()) {
                int Enroll = set.getInt(1);
                String sname = set.getString(2);
                String semail = set.getString(3);
                String sphone = set.getString(4);
                String sclg_name = set.getString(5);
                String scourse = set.getString(6);
                String scity = set.getString(7);
                if(s1==Enroll);
                {
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t\t\t\t         "+TEXT_BG_GREEN+"  Enrollment Number    : | " + Enroll+"  "+ANSI_RESET);
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t\t\t\t         Student Name         : | " + sname);
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t\t\t\t         Student Email        : | " + semail);
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t\t\t\t         Student phone Number : | " + sphone);
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t\t\t\t         Student School Name  : | " + sclg_name);
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t\t\t\t         Student Class Name   : | " + scourse);
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t\t\t\t         Student City Name    : |  " + scity);
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     
                     System.out.print("\t\t\t\t\t         Enter Student  Name : ");
                     String sname2 = br.readLine();
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     String semail2=Students.EmailEnter();

                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     int sphone2=Students.NumberEnter();

                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.print("\t\t\t\t\t         Enter Student School Name         : ");
                     String sclg_name2 = br.readLine();
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.print("\t\t\t\t\t         Enter Student  Class Name : ");
                     String scopurse2 = br.readLine();
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.print("\t\t\t\t\t         Enter Student City         : ");
                     String scity2 = br.readLine();
                     System.out.println("\t\t       | |                                                                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     String up = "update  student set sname=?,semail=?,sphone=?,sclg_name=?,scopurse=?,scity=? where Enroll="+Enroll;
                     PreparedStatement preparedStmt = con.prepareStatement(up);
                     preparedStmt.setString(1,sname2);
                     preparedStmt.setString(2,semail2);
                     preparedStmt.setInt(3,sphone2);
                     preparedStmt.setString(4,sclg_name2);
                     preparedStmt.setString(5,scopurse2);
                     preparedStmt.setString(6,scity2);
                     preparedStmt.executeUpdate();
                     f = true;


                }
                if(s1!=Enroll){
                	System.out.print("not match");
                }

               

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

	private static String nextLine() {
		// TODO Auto-generated method stub
		return null;
	}

	private static Scanner Scanner(InputStream in) {
		// TODO Auto-generated method stub
		return null;
	}

	public static boolean matchData(int enroll) throws SQLException {
   	 	
		boolean b = false;
		Connection con = Connect.createc();
		
		String q = "select * from  student where Enroll ="+enroll;
		
		Statement st = con.createStatement();
		  
		ResultSet set = st.executeQuery(q);
		
		if(set.next())
		{
			int en = set.getInt(1);
			b = true;

			
		}
		else {
//	        // not match
			}
		
		return b;
		
	}
//-----------------------------------------------------------------------------------------------------------//
	public static String matchgender() throws IOException{
		String b = "false";
        System.out.print("\t\t                                 Enter Student Gender (male=1 , female=2) : ");
        try {
        int sgender = Integer.parseInt(br.readLine());
       
		 if(sgender==1)
			{
			 
				String Sgen="male";
				
				return Sgen;
				
			}
		 if(sgender==2)
		 {
			 String Sgen="female";
				return Sgen;
		 }
		 else
		 {
			 System.out.print("\t\t\t\t                         Note valid Gender!!");
				matchgender();
				return b;
				
		 }
        }
        catch(NumberFormatException e)
        {
            System.out.println("\t\t       | |                                                                                 | |");
            System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
        	System.out.println("\t\t       | |                       Plase Enter you valid Choide....!!                        | |");
            System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
			matchgender();

        }
    	return b;
         		
	}
//------------------------------------------------------------------------------------------------------------//
	public static boolean malStudentrecord() {
		// int s1;
		int count=0;
        boolean f = false;
        try {
            Connection con = Connect.createc();
            String q = "select * from student where sgender='male'";
            // PreparedStatement psmt=con.prepareStatement(q);
            // psmt.setInt(1,s1);
            Statement stmt = con.createStatement();

            ResultSet set = stmt.executeQuery(q);

            f = true;
            while (set.next()) {
                int Enroll = set.getInt(1);
                String sname = set.getString(2);
                String semail = set.getString(3);
                String sphone = set.getString(4);
                String sclg_name = set.getString(5);
                String scourse = set.getString(6);
                String scity = set.getString(7);
                String sgender=set.getString(8);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t\t\t        "+TEXT_BG_GREEN+"  Enrollment Number    : | " + Enroll+"  "+ANSI_RESET);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Name         : | " + sname);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Email        : | " + semail);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student phone Number : | " + sphone);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student School Name : | " + sclg_name);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Class Name  : | " + scourse);
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student Gender       : | " + sgender);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t\t\t          Student City Name    : |  " + scity);
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                count ++;
            }
            if(count<=10)
            {
                System.out.println("\t\t       | |                "+RED_BACKGROUND+"Total Student :"+0+count+ANSI_RESET+"                                                | |");

            }
            else
            {
                System.out.println("\t\t       | |                "+RED_BACKGROUND+"Total Student :"+count+ANSI_RESET+"                                                | |");
	
            }
            
            System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
	}
//-----------------------------------------------------------------------------------------------------------//
	public static boolean femalStudentrecord() {
		// int s1;
				int count=0;
		        boolean f = false;
		        try {
		            Connection con = Connect.createc();
		            String q = "select * from student where sgender='female'";
		            // PreparedStatement psmt=con.prepareStatement(q);
		            // psmt.setInt(1,s1);
		            Statement stmt = con.createStatement();

		            ResultSet set = stmt.executeQuery(q);

		            f = true;
		            while (set.next()) {
		                int Enroll = set.getInt(1);
		                String sname = set.getString(2);
		                String semail = set.getString(3);
		                String sphone = set.getString(4);
		                String sclg_name = set.getString(5);
		                String scourse = set.getString(6);
		                String scity = set.getString(7);
		                String sgender=set.getString(8);
		                System.out.println("\t\t       | |                                                                                 | |");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t       | |                                                                                 | |");
		                System.out.println("\t\t\t\t        "+TEXT_BG_GREEN+"  Enrollment Number    : | " + Enroll+"  "+ANSI_RESET);
		                System.out.println("\t\t       | |                                                                                 | |");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t\t\t          Student Name         : | " + sname);
		                System.out.println("\t\t       | |                                                                                 | |");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t\t\t          Student Email        : | " + semail);
		                System.out.println("\t\t       | |                                                                                 | |");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t\t\t          Student phone Number : | " + sphone);
		                System.out.println("\t\t       | |                                                                                 | |");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t\t\t          Student School Name  : | " + sclg_name);
		                System.out.println("\t\t       | |                                                                                 | |");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t\t\t          Student Class Name   : | " + scourse);
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t\t\t          Student Gender       : | " + sgender);
		                System.out.println("\t\t       | |                                                                                 | |");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t\t\t          Student City Name    : |  " + scity);
		                System.out.println("\t\t       | |                                                                                 | |");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
	                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                count ++;
		            }
		            if(count<=10)
		            {
		                System.out.println("\t\t       | |                "+RED_BACKGROUND+"Total Student :"+0+count+ANSI_RESET+"                                                | |");

		            }
		            else
		            {
		                System.out.println("\t\t       | |                "+RED_BACKGROUND+"Total Student :"+count+ANSI_RESET+"                                                | |");
			
		            }
		            
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		        return f;
	}
	
	
}
	
