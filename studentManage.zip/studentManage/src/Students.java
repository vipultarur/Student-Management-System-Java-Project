import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Students {
	static String RED_BACKGROUND="\u001B[41m";
    static String ANSI_RESET="\u001b[0m";
    static String ANSI_RED="\u001b[31m";
	static String ANSI_GREEN = "\033[0;32m";
	static String ANSI_YELLOW="\033[0;33m";
	static String TEXT_BG_GREEN  = "\u001B[42m";
	static String CYAN_BACKGROUND="\u001B[46m";

    private int sid;
    private int Enroll;
    private String sname;
    private String semail;
    private int sphone;
    private String sclg_name;
    private String scourse;
    private String scity;
    private String sgender;
    public Students(int Enroll, String sname, String semail, int sphone, String sclg_name,
            String scourse,String sgender, String scity) {
        super();
        this.sid = sid;
        this.sname = sname;
        this.semail = semail;
        this.sphone = sphone;
        this.sclg_name = sclg_name;
        this.scourse = scourse;
        this.scity = scity;
        this.Enroll = Enroll;
        this.sgender=sgender;
    }

    

    public int getSid() {
		return sid;
	}



	public void setSid(int sid) {
		this.sid = sid;
	}



	public int getEnroll() {
		return Enroll;
	}



	public void setEnroll(int enroll) {
		Enroll = enroll;
	}



	public String getSname() {
		return sname;
	}



	public void setSname(String sname) {
		this.sname = sname;
	}



	public String getSemail() {
		return semail;
	}



	public void setSemail(String semail) {
		this.semail = semail;
	}



	public int getSphone() {
		return sphone;
	}



	public void setSphone(int sphone) {
		this.sphone = sphone;
	}



	public String getSclg_name() {
		return sclg_name;
	}



	public void setSclg_name(String sclg_name) {
		this.sclg_name = sclg_name;
	}



	public String getScourse() {
		return scourse;
	}



	public void setScourse(String scourse) {
		this.scourse = scourse;
	}



	public String getScity() {
		return scity;
	}



	public void setScity(String scity) {
		this.scity = scity;
	}



	public String getSgender() {
		return sgender;
	}



	public void setSgender(String sgender) {
		this.sgender = sgender;
	}



	

    public String toString() {
		return "Students [sid=" + sid + ", Enroll=" + Enroll + ", sname=" + sname + ", semail=" + semail + ", sphone="
				+ sphone + ", sclg_name=" + sclg_name + ", scourse=" + scourse + ", scity=" + scity + ", sgender="
				+ sgender + "]";
	}



	public Students() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public static boolean Numbervalid(CharSequence sphone)
    {
    	 final String PHONE_REGEX = "^\\d{10}$";
    	 final Pattern pattern = Pattern.compile(PHONE_REGEX);
    	 System.out.println(sphone);
    	 final Matcher matcher = pattern.matcher(sphone);
    	 System.out.println(matcher.matches()); 
    	 
		if(matcher.matches()==true)
		{
			return true;
		}
		else
		{
			return false;
		}
    	
    }

	public static int NumberEnter() {
		Scanner sc=new Scanner(System.in);
		 System.out.print("\t\t                                 Enter Student Phone        : ");
		 int sphone2 = sc.nextInt();
		 int sphone3=sphone2;
		   
		 int count = 0;  
		 while(sphone3 != 0)  
		 {  
		 // removing the last digit of the number n  
			 sphone3 = sphone3 / 10;  
		 // increasing count by 1  
		 count = count + 1;  
		 }  
		 if(count==10)
		 {
			 return sphone2;  
			 

		 }
		 else
		 {
			 NumberEnter();
		 }
		 
		 return sphone2;  


	}



	public static String EmailEnter() {
		
		Scanner sc=new Scanner(System.in);
		 System.out.print("\t\t                                 Enter Student Email        : ");
		 String semail = sc.nextLine();
		
		final String PHONE_REGEX = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
  	 final Pattern pattern = Pattern.compile(PHONE_REGEX);
  	 final Matcher matcher = pattern.matcher(semail);
  	 
		if(matcher.matches()==true)
		{
			return  semail;
		}
		else
		{
           System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
           System.out.println("\t\t       | |  "+ANSI_RED+"                      Please Enter Your Valid Email            "+ANSI_RESET+"                | |");
           System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

           EmailEnter();
			return null;
			
		}		
		
		
	}	

}
