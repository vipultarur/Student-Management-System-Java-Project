import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;


public class Home {
	
	static String ANSI_RESET="\u001b[0m";
	static String ANSI_RED="\u001b[31m";
	static String ANSI_GREEN = "\033[0;32m";
	static String ANSI_YELLOW="\033[0;33m";
	static String RED_BACKGROUND="\u001B[41m";
	
	
	
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public static void main2() throws NumberFormatException, IOException, SQLException, InterruptedException {

        
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |              "+ANSI_GREEN+"          You are login Successfully                               "+ANSI_RESET+"| |");
                
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       | |                          M     E      N      U                                  | |");
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                       [1] Add New Student Record                                | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                       [2] Show All Student Record                               | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                       [3] Search Student Record                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                       [4] Delete Student Record                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                       [5] Update Student Record                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                       [6] Generate Report                                       | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.println("\t\t       | |                       [7] Exit                                                  | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                System.out.print("\t\t\t                         Enter your choice: ");
                int ch = Integer.parseInt(br.readLine()); 
                System.out.println("\t\t       | |                                                                                 | |");
                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
         
                if (ch == 1) {
//                	Scanner sc = new Scanner(System.in);
                	 System.out.print("\t\t\t                         Enter Student  EnrollmentNumber : ");
                     int Enroll= Integer.parseInt(br.readLine());
                	
                         try {
						if(Connect.matchData(Enroll))
						{
							
							System.out.println(ANSI_RED+"\t\t\t\t                         Enrollment Number is Already Exist...!!"+ANSI_RESET);
							Home.main2();
						}
						else {
				    
			        System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    System.out.print("\t\t                                 Enter Student  Name : ");
                    String sname = br.readLine();
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                    String semail=Students.EmailEnter();
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                  
                    int sphone=Students.NumberEnter();
 
		                
                    
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                    System.out.print("\t\t                                 Enter School Name  : ");
                    String sclg_name = br.readLine();
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                    System.out.print("\t\t                                 Enter Class  Name  : ");
                    String scourse = br.readLine();
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                    String sgender=Connect.matchgender();
                   
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    
                    System.out.print("\t\t                                 Enter City Name  : ");
                    String scity = br.readLine();
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    Students st = new Students(Enroll, sname, semail, sphone, sclg_name, scourse,sgender, scity);
                    boolean ans1 = Connect.insertRecord(st);
                    if (ans1) {
                        System.out.println("\t\t       | |                  "+ANSI_GREEN+"      Student is inserted.....              "+ANSI_RESET+"                    | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        main2();
                    } else {
                        System.out.println("\t\t       | |               "+ANSI_RED+"         Student is not inserted.....          "+ANSI_RESET+"                    | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        main2();
                    }
						}
                         }
                    catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 

                } else if (ch == 2) {
                    boolean ans = Connect.ShowAllStudent();
                    if (ans) {
                        System.out.println("\t\t       | |                "+ANSI_GREEN+"       Show All Record...             "+ANSI_RESET+"                           | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        main2();
                    } else {
                        System.out.println("\t\t       | |             "+ANSI_RED+"          Record Not Faound.....     "+ANSI_RESET+"                               | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        main2();
                    }

                } else if (ch == 3) {
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       | |                       [1] Any Student Record                                    | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       | |                       [2] Male Student Record                                   | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       | |                       [3] Female Student Record                                 | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.print("\t\t       | |                       Enter Your Choice :");

                    int ch2 = Integer.parseInt(br.readLine()); 
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    if(ch2==1)
                    {
                    	
                    System.out.print("\t\t\t                         Enter Student id to Show :");
                   
                    // int userid=br.readLine());
                    boolean ans = Connect.oneStudentrecord();
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    if (ans) {
                        System.out.println("\t\t       | |        "+ANSI_GREEN+"               Student Showed.....       "+ANSI_RESET+"                                | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        main2();


                    } else {
                        System.out.print("\t\t\t\t     | |             "+ANSI_RED+"    Student is not exist.....               "+ANSI_RESET+"                        | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        main2();
                    }

                    }else if(ch2==2){
                        boolean ans = Connect.malStudentrecord();
                        main2();
                    }else if(ch2==3){
                        boolean ans = Connect.femalStudentrecord();
                        main2();

                    }{
                    	System.out.println("\t\t       | |            "+ANSI_RED+"           Plase Enter your valid Choise....!!    "+ANSI_RESET+"                   | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
            	        main2();
                    }
                    
                } else if (ch == 4) {
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    System.out.println("\t\t       | |                       [1] Delete one Student Record                             | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    System.out.println("\t\t       | |                       [2] Delete All Student Record                             | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    System.out.print("\t\t       | |                       Enter Your Choice :");
                   int ch41 = Integer.parseInt(br.readLine()); 
                   System.out.println("\t\t       | |                                                                                 | |");
                   System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
               	
               	     if(ch41==1)
               	        {
                         System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        System.out.print("\t\t\t\t                 Enter Student id to Delete ::");
                        int userid = Integer.parseInt(br.readLine());
                        boolean ans = Connect.deleteStudent(userid);
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        

                        if (ans) {
                            System.out.println("\t\t       | |                  "+ANSI_GREEN+"     Student is Deleted.....        "+ANSI_RESET+"                           | |");
                            System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                            main2();


                        } else {
                            System.out.println("\t\t       | |               "+ANSI_GREEN+"        Student is Not Deleted.....       "+ANSI_RESET+"                        | |");
                            System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                            main2();


                        }
               	    	}
               	     else if(ch41==2)
               	     {
               	    	 boolean ans = Connect.deleteAllStudent();
                         System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                         

                         if (ans) {
                             System.out.println("\t\t       | |          "+ANSI_GREEN+"             Student  is Deleted.....      "+ANSI_RESET+"                            | |");
                             System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                             main2();


                         } else {
                             System.out.println("\t\t       | |            "+ANSI_RED+"           Student  is Not Deleted.....        "+ANSI_RESET+"                      | |");
                             System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                             main2();


                         }
               	    	 main2();

               	     }
               	     else
               	     {
               	    	System.out.println("\t\t       | |  "+ANSI_RED+"                      Plase Enter you valid vhoide....!!            "+ANSI_RESET+"           | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
            	        main2();
               	     }
                	
                    

                } else if (ch == 5) {
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                    System.out.print("\t\t\t\t                 Enter Student id to Update :");
                            // int userid=Integer.parseInt(br.readLine());
                    // Connect.oneStudentrecord();

                    boolean ans = Connect.UpdateStudent();
                    if (ans) {
                    	System.out.println("\t\t       | |                                                                                 | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                        System.out.println("\t\t       | |           "+ANSI_GREEN+"            Student is updated.....   "+ANSI_RESET+"                                | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        main2();


                    } else {
                        System.out.print("\t\t       | |             "+ANSI_RED+"          Student is Not Updated.....   "+ANSI_RESET+"                              | |");
                        System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                        main2();


                    }

                } else if (ch == 6) {
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       | |                       [1] Generate All Student Report                           | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       | |                       [2] Generate Male Student Record                          | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.println("\t\t       | |                       [3] Generate Female Student Record                        | |");
                     System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                     System.out.print("\t\t       | |                       Enter Your Choice :");

                    int ch3 = Integer.parseInt(br.readLine()); 
                    System.out.println("\t\t       | |                                                                                 | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                	
                	     if(ch3==1)
                	        {
                	    	 boolean ansb=Pdf_genaral.genarate();
                	    	 if (ansb) {
                             	System.out.println("\t\t       | |                                                                                 | |");
                                 System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                                 System.out.println("\t\t       | |           "+ANSI_GREEN+"            Student Report Generate.....   "+ANSI_RESET+"                           | |");
                                 System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                                 main2();


                             } else {
                                 System.out.print("\t\t       | |             "+ANSI_RED+"          Student Report is Not Generate.....   "+ANSI_RESET+"                       | |");
                                 System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                                 main2();


                             }
                	    	 
                	    	}
                	     else if(ch3==2)
                	     {
                	    	 boolean ansb2=Pdf_genaral.genarate2();
                	    	 if (ansb2) {
                              	System.out.println("\t\t       | |                                                                                 | |");
                                  System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                                  System.out.println("\t\t       | |           "+ANSI_GREEN+"            Student Report Generate.....   "+ANSI_RESET+"                           | |");
                                  System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                                  main2();


                              } else {
                                  System.out.print("\t\t       | |             "+ANSI_RED+"          Student Report is Not Generate.....   "+ANSI_RESET+"                       | |");
                                  System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                                  main2();
                              }  
 
                	     }
                	     else if(ch3==3)
                	     {
                	    	boolean ansb3= Pdf_genaral.genarate3();
                	    	if (ansb3) {
                              	System.out.println("\t\t       | |                                                                                 | |");
                                  System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");

                                  System.out.println("\t\t       | |           "+ANSI_GREEN+"            Student Report Generate.....   "+ANSI_RESET+"                           | |");
                                  System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                                  main2();


                              } else {
                                  System.out.print("\t\t       | |             "+ANSI_RED+"          Student Report is Not Generate.....   "+ANSI_RESET+"                       | |");
                                  System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                                  main2();
                              }  
                	     }
                	     else{
                	    	 System.out.println("\t\t       | |  "+ANSI_RED+"                      Plase Enter you valid vhoide....!!            "+ANSI_RESET+"           | |");
                             System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
                 	         main2();
                	    	 
                	     }
                	              

                } else if(ch==7)
                {
                    System.out.println("\t\t       "+RED_BACKGROUND+"+-+---------------------------------------------------------------------------------+-+"+ANSI_RESET);
                    System.out.println("\t\t       "+RED_BACKGROUND+"| |                       THANKS FOR USING THIS SYSTEM.........                     | |"+ANSI_RESET);
                    System.out.println("\t\t       "+RED_BACKGROUND+"+-+---------------------------------------------------------------------------------+-+"+ANSI_RESET);
                  	System.out.println("\t\t       | |                                                                                 | |");
                    Admin.adminlogin();                	
                }
                else {
                	System.out.println("\t\t       | |  "+ANSI_RED+"                      Plase Enter you valid vhoide....!!            "+ANSI_RESET+"           | |");
                    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
        	        main2();
                }
            }

        
    }
    
