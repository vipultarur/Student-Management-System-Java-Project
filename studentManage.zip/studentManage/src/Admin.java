import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Admin {
	static String RED_BACKGROUND="\u001B[41m";
    static String ANSI_RESET="\u001b[0m";
    static String ANSI_RED="\u001b[31m";
	static String ANSI_GREEN = "\033[0;32m";
	static String ANSI_YELLOW="\033[0;33m";
	static String GREEN_BACKGROUND  = "\u001B[42m";
	static String CYAN_BACKGROUND="\u001B[46m";
	private String user_password;
	private String user_name;
	
		public String getUser_password() {
			return user_password;
		}
		
		public void setUser_password(String user_password) {
			this.user_password = user_password;
		}
		
		public String getUser_name() {
			return user_name;
		}
		
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		
		public Admin(String user_password, String user_name) {
			super();
			this.user_password = user_password;
			this.user_name = user_name;
		}
		
		public static boolean adminlogin() {
			String textInBold = "WellCome Student Management System";
			
			 boolean f = false;
			 int count = 1;
			    String user;
			    String pass;
			    Scanner s = new Scanner(System.in);

		        try {
		            Connection con = Connect.createc();
		            String q = "select * from admin where user_password='vipul123'";
		            Statement stmt = con.createStatement();

		            ResultSet set = stmt.executeQuery(q);

		            f = true;
		            while (set.next()) {
		                String user_password = set.getString(1);
		                String user_name = set.getString(2);
		               
		                System.out.println("\t\t       "+CYAN_BACKGROUND+"+-+---------------------------------------------------------------------------------+-+"+ANSI_RESET);
		                System.out.println("\t\t       "+CYAN_BACKGROUND+"| |                           Developed by : VIPUL TARUR IC-4                       | |"+ANSI_RESET);
		                System.out.println("\t\t       "+CYAN_BACKGROUND+"+-+---------------------------------------------------------------------------------+-+"+ANSI_RESET);
		                System.out.println("\t\t       | |                                                                                 | |");

		                System.out.println("\t\t       "+GREEN_BACKGROUND+"| |                                                                                 | |"+ANSI_RESET);
		                System.out.println("\t\t       \033[0;1m"+GREEN_BACKGROUND+"| |                      "+textInBold+"                         | |"+ANSI_RESET);
		                System.out.println("\t\t       "+GREEN_BACKGROUND+"| |                                                                                 | |"+ANSI_RESET);
		                System.out.println("\t\t       | |                                                                                 | |");
		                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t       | |             "+CYAN_BACKGROUND+"                       ADMIN  LOGIN                       "+ANSI_RESET+"          | |");
		                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                System.out.println("\t\t       | |                                                                                 | |");
		                System.out.println("\t\t       | |                                                                                 | |");
		                System.out.println("\t\t       | |                                                                                 | |");
		                while (true) {

		                    if (count < 2) {

		                         System.out.print("\n\t\t\t\t\t\t      Enter Admin Id : ");
		                         user = s.next();
		                         
		                         if (!(user.equals(user_name))) {
		                        	 System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                             System.out.println("\t\t       | |                         "+ANSI_RED+"Your username  are incorrect"+ANSI_RESET+"                            | |");
		                             System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                             System.out.println("\t\t       | |                         "+ANSI_RED+"Please enter valid  username"+ANSI_RESET+"                            | |");
		                             adminlogin();
		                         }
		                    
		                         System.out.print("\n\t\t\t\t\t\t      Enter Password : ");
		                         pass = s.next();

		                         System.out.println("\t\t       | |                                                                                 | |");
		                         System.out.println("\t\t       | |                                                                                 | |");
		                         System.out.println("\t\t       | |                                                                                 | |");
		                         
		                         if(!(pass.equals(user_password)))
		                         {
		                        	 System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                             System.out.println("\t\t       | |                         "+ANSI_RED+"Your password  are incorrect"+ANSI_RESET+"                            | |");
		                             System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
		                             System.out.println("\t\t       | |                         "+ANSI_RED+"Please enter valid  password"+ANSI_RESET+"                            | |");
		                             adminlogin();
		                         }
		                        count += 1;
		                        Home.main2();
		                    }
		               }
		           }
		

		        } catch (Exception e) {
		            e.printStackTrace();
		      }
		        return f;
		
		}
}
