import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

	public class Home1 {
	static String ANSI_RESET="\u001b[0m";
	static String ANSI_RED="\u001b[31m";
	static String ANSI_GREEN = "\033[0;32m";
	static String BLUE_BACKGROUND="\u001B[44m";
	static String CYAN_BACKGROUND="\u001B[41m";
	
	public static void main(String[] args) throws InterruptedException {
         
    	
    	try {
    		Logo.logo();
    		Admin.adminlogin();
			Home.main2();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    	
 }


