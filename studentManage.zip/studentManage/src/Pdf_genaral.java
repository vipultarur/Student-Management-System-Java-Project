import java.io.*;
import java.sql.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.util.*;


public class Pdf_genaral{
	static Connection con;
	 	static String RED_BACKGROUND="\u001B[41m";
	    static String ANSI_RESET="\u001b[0m";
	    static String ANSI_RED="\u001b[31m";
		static String ANSI_GREEN = "\033[0;32m";
		static String ANSI_YELLOW="\033[0;33m";
		static String TEXT_BG_GREEN  = "\u001B[42m";
		static String CYAN_BACKGROUND="\u001B[46m";

    // -----------------------------------------DATABAS CONNECTION-------------------------------------------------------//
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public static Connection createc() {
        // load driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/students";
            String user = "root";
            String password = "vipul@2003#1";

            try {
                con = DriverManager.getConnection(url, user, password);
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return con;

    }
//---------------------------------------------------------------------------------------------------------------------

	public static boolean genarate() {
		boolean ans=false;
	try {
    		String file_name="D:\\STUDY\\student.pdf";
    		
    		Document  document=new Document();
    		PdfWriter.getInstance(document,new FileOutputStream(file_name));

    		
    		document.open();
    		document.add(Image.getInstance("C:\\Users\\VIPUL\\OneDrive\\Pictures\\Screenshots\\ss2.png"));
    		Paragraph para=new  Paragraph(" \t\t\t\t\tAll Student Records\n ");
    		PdfPTable table=new PdfPTable(7);
    		PdfPCell c1=new PdfPCell(new Phrase("Enrollmet"));
    		table.addCell(c1);
    		c1=new PdfPCell(new Phrase("Name \t\t"));
    		table.addCell(c1);
    		c1=new PdfPCell(new Phrase("Email\t\t"));
    		table.addCell(c1);
    		c1=new PdfPCell(new Phrase("Phone Number\t\t"));
    		table.addCell(c1);
    		c1=new PdfPCell(new Phrase("Gender\t\t"));
    		table.addCell(c1);
    		c1=new PdfPCell(new Phrase("Class\t\t"));
    		table.addCell(c1);
    		c1=new PdfPCell(new Phrase("scity\t\t"));
    		table.addCell(c1);
    		 int count=00;
    		 
    		table.setHeaderRows(count);
                document.add(para);
                 Connection con = Connect.createc();
                 String q = "select * from student;";
                 Statement stmt = con.createStatement();

                 ResultSet set = stmt.executeQuery(q);
                

                   while (set.next()) {
	
               	   		String sss54="male";
                	   int ss=set.getInt("Enroll");
                	   String ss1 = Integer.toString(ss);
                	   String ss2=set.getString("sname");
                	   String ss3=set.getString("semail");
                	   String ss4=set.getString("sphone");
                	   String ss5=set.getString("sgender");
                	   String ss6=set.getString("scopurse");	
                	   String ss7=set.getString("scity");


                	    table.addCell(ss1);
                	   	table.addCell(ss2);
                	   	table.addCell(ss3);
                	   	table.addCell(ss4);
                	   	table.addCell(ss5);
                	   	table.addCell(ss6);
                	   	table.addCell(ss7);
                	   	count ++;
                	   
                   }
                   		
                        document.add(table);
                        if(count==0)
                   		{
                            Paragraph nore=new  Paragraph("\n \t\t\t\t\t\t\t\tRecord Not Faund !!!");
                            document.add(nore);

                   		}
                        Paragraph para2=new  Paragraph("\n \t\t\t\t\tTotal Student :"+count+"\n");
           	    		document.add(para2);
           	    		
           	    		
          document.close();
          ans=true;
    	}
    	catch(Exception e)
    	{
    		System.out.print(e);
    		
    	}   
	return ans;
	}
//---------------------------------------------------------------------------------------------------------------
	public static boolean genarate2() {
		String sss="male";
		boolean ans=false;

		try {
	    		String file_name="D:\\STUDY\\MALstudent.pdf";
	    		
	    		Document  document=new Document();
	    		PdfWriter.getInstance(document,new FileOutputStream(file_name));

	    		
	    		document.open();
	    		document.add(Image.getInstance("C:\\Users\\VIPUL\\OneDrive\\Pictures\\Screenshots\\ss2.png"));
	    		Paragraph para=new  Paragraph(" \t\t\t\t\t Mal Student Records\n ");
	    		PdfPTable table=new PdfPTable(7);
	    		PdfPCell c1=new PdfPCell(new Phrase("Enrollmet"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Name \t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Email\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Phone Number\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Gender\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Class\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("scity\t\t"));
	    		table.addCell(c1);
	    		int count=00;
	    		table.setHeaderRows(count);
	                document.add(para);
	                 Connection con = Connect.createc();
	                 String q = "select * from student where sgender='male'";

	                 //String q = "select * from student;";
	                 Statement stmt = con.createStatement();

	                 ResultSet set = stmt.executeQuery(q);


	                   while (set.next()) {
		

	                	   int ss=set.getInt("Enroll");
	                	   String ss1 = Integer.toString(ss);
	                	   String ss2=set.getString("sname");
	                	   String ss3=set.getString("semail");
	                	   String ss4=set.getString("sphone");
	                	   String ss5=set.getString("sgender");
	                	   String ss6=set.getString("scopurse");	
	                	   String ss7=set.getString("scity");
	                	   
	                		    table.addCell(ss1);
		                	   	table.addCell(ss2);
		                	   	table.addCell(ss3);
		                	   	table.addCell(ss4);
			                	table.addCell(ss5);
		                	   	table.addCell(ss6);
		                	   	table.addCell(ss7);
	                	  
	                		    
		                	   	count ++;
	                	   
	                       }		
	                        document.add(table);
	                        if(count==0)
	                   		{
	                            Paragraph nore=new  Paragraph("\n \t\t\t\t\t\t\t\tRecord Not Faund !!!");
	                            document.add(nore);

	                   		}
	                        Paragraph para2=new  Paragraph("\n \t\t\t\t\tTotal Student :"+count+"\n");
	           	    		document.add(para2);

	          document.close();
	          ans=true;
	    	}
	    	catch(Exception e)
	    	{
	    		System.out.print(e);
	    	}   
		   return ans;
		}
//--------------------------------------------------------------------------------------------------------------------
	public static boolean genarate3() {
		boolean ans=false;
		try {
	    		String file_name="D:\\STUDY\\femalStudent.pdf";
	    		
	    		Document  document=new Document();
	    		PdfWriter.getInstance(document,new FileOutputStream(file_name));

	    		
	    		document.open();
	    		document.add(Image.getInstance("C:\\Users\\VIPUL\\OneDrive\\Pictures\\Screenshots\\ss2.png"));
	    		Paragraph para=new  Paragraph(" \t\t\t\t\tFemale Student Records\n ");
	    		PdfPTable table=new PdfPTable(7);
//	    		System.out.println(table);
	    		PdfPCell c1=new PdfPCell(new Phrase("Enrollmet"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Name \t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Email\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Phone Number\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Gender\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Class\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("scity\t\t"));
	    		table.addCell(c1);
	    		int count=00;
	    		table.setHeaderRows(count);
	                document.add(para);
	                 Connection con = Connect.createc();
	                 String q = "select * from student where sgender= 'female'";
                 
	                 //String q = "select * from student;";
	                 Statement stmt = con.createStatement();

	                 ResultSet set = stmt.executeQuery(q);


	                   while (set.next()) {
		

	                	   int ss=set.getInt("Enroll");
	                	   String ss1 = Integer.toString(ss);
	                	   String ss2=set.getString("sname");
	                	   String ss3=set.getString("semail");
	                	   String ss4=set.getString("sphone");
	                	   String ss5=set.getString("sgender");
	                	   String ss6=set.getString("scopurse");	
	                	   String ss7=set.getString("scity");
	                	   
	                	   table.addCell(ss1);
	                	   	table.addCell(ss2);
	                	   	table.addCell(ss3);
	                	   	table.addCell(ss4);
		                	table.addCell(ss5);
	                	   	table.addCell(ss6);
	                	   	table.addCell(ss7);
	                	   	
	                	   	count ++;
	                	   
	        	    		
                      }		
                       document.add(table);
                       if(count==0)
                  		{
                           Paragraph nore=new  Paragraph("\n \t\t\t\t\t\t\t\tRecord Not Faund !!!");
                           document.add(nore);

                  		}
                     Paragraph para2=new  Paragraph("\n \t\t\t\t\tTotal Student :"+count+"\n");
       	    		 document.add(para2);
         document.close();
         ans=true;
   	}
   	catch(Exception e)
   	{
   		System.out.print(e);
   	}      	
	return ans;
	}
	public static boolean onestudent() {
		boolean ans=false;
		Scanner sc=new Scanner(System.in);

		try {
	    		String file_name="D:\\STUDY\\MALstudent.pdf";
	    		
	    		Document  document=new Document();
	    		PdfWriter.getInstance(document,new FileOutputStream(file_name));
	    		
	    		String path="C:\\Users\\VIPUL\\OneDrive\\Pictures\\Screenshots\\";
	    		System.out.println("\t\t       "+RED_BACKGROUND+"+-+---------------------------------------------------------------------------------+-+"+ANSI_RESET);
                System.out.println("\t\t       "+RED_BACKGROUND+"| |                       Please Image Store This path                      | |"+ANSI_RESET);
                System.out.println("\t\t       "+RED_BACKGROUND+"+-+---------------------------------------------------------------------------------+-+"+ANSI_RESET);
                System.out.print("\t\t                                 Enter Image Name  : ");
	    		String ename=sc.nextLine();
	    		
	    		document.open();
	    		document.add(Image.getInstance("C:\\Users\\VIPUL\\OneDrive\\Pictures\\Screenshots\\ss2.png"));
	    		Paragraph para=new  Paragraph(" \t\t\t\t\t Male Student Records\n ");
	    		PdfPTable table=new PdfPTable(7);
	    		PdfPCell c1=new PdfPCell(new Phrase("Enrollmet"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Name \t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Email\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Phone Number\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Gender\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("Class\t\t"));
	    		table.addCell(c1);
	    		c1=new PdfPCell(new Phrase("scity\t\t"));
	    		table.addCell(c1);
	    		int count=00;
	    		table.setHeaderRows(count);
	                document.add(para);
	                 Connection con = Connect.createc();
	                 String q = "select * from student where sgender='male'";

	                 //String q = "select * from student;";
	                 Statement stmt = con.createStatement();

	                 ResultSet set = stmt.executeQuery(q);


	                   while (set.next()) {
		

	                	   int ss=set.getInt("Enroll");
	                	   String ss1 = Integer.toString(ss);
	                	   String ss2=set.getString("sname");
	                	   String ss3=set.getString("semail");
	                	   String ss4=set.getString("sphone");
	                	   String ss5=set.getString("sgender");
	                	   String ss6=set.getString("scopurse");	
	                	   String ss7=set.getString("scity");
	                	   
	                		    table.addCell(ss1);
		                	   	table.addCell(ss2);
		                	   	table.addCell(ss3);
		                	   	table.addCell(ss4);
			                	table.addCell(ss5);
		                	   	table.addCell(ss6);
		                	   	table.addCell(ss7);
	                	  
	                		    
		                	   	count ++;
	                	   
	                       }		
	                        document.add(table);
	                        if(count==0)
	                   		{
	                            Paragraph nore=new  Paragraph("\n \t\t\t\t\t\t\t\tRecord Not Faund !!!");
	                            document.add(nore);

	                   		}
	                        Paragraph para2=new  Paragraph("\n \t\t\t\t\tTotal Student :"+count+"\n");
	           	    		document.add(para2);

	          document.close();
	          ans=true;
	    	}
	    	catch(Exception e)
	    	{
	    		System.out.print(e);
	    	}   
		   return ans;
		}
}
