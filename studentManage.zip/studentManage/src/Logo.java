import java.io.Console;

public class Logo {

public static void logo()
{
//	\UOO1b[0m  \u001b[31m SHISHYA

	String ANSI_RESET="\u001b[0m";
	String ANSI_YELLOW="\033[0;33m";
	String ANSI_PURPLE="\u001B[96m";
    System.out.println(ANSI_YELLOW+"\t\t       +-+---------------------------------------------------------------------------------+-+");
    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
    System.out.println("\t\t       | |  *****   ***   *** ***  *****    ***   ***  ***        ***       * *            | |");
    System.out.println("\t\t       | | * *** *  * *   * * *** * *** *   * *   * *   * *      * *       * * *           | |");
    System.out.println("\t\t       | | * *  * * * *   * *     * *  * *  * *   * *     * *   * *       * * * *          | |");
    System.out.println("\t\t       | | * *  *** * *   * * *** * *  ***  * *   * *      * *** *       * *   * *         | |");
    System.out.println("\t\t       | |  * *     * ***** * * *  * *      * ***** *        * *        * *     * *        | |");
    System.out.println("\t\t       | |    * *   * ***** * * *    * *    * ***** *        * *       * ********* *       | |");
    System.out.println("\t\t       | |     * *  * *   * * * *      * *  * *   * *        * *      * *********** *      | |");
    System.out.println("\t\t       | | ***  * * * *   * * * * ***   * * * *   * *        * *     * *           * *     | |");
    System.out.println("\t\t       | | * ***  * * *   * * * * *  ***  * * *   * *        * *    * *             * *    | |");
    System.out.println("\t\t       | |  ******  ***   *** ***   *****   ***   ***        ***   ***               ***   | |");
    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+");
    System.out.println("\t\t       +-+---------------------------------------------------------------------------------+-+"+ANSI_RESET);


}

}
